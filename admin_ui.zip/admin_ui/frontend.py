import streamlit as st
import requests
import os

st.set_page_config(page_title="Video Processing", page_icon="🎬", layout="wide")
st.title("🎬 Video Processing App")

uploaded_file = st.file_uploader("Upload a video (max 10GB)", type=["mp4","avi","mov","mkv"])

if uploaded_file:
    st.info(f"File uploaded: {uploaded_file.name}")

    if st.button("Process Video"):
        with st.spinner("Uploading and processing video..."):
            # Upload
            files = {"file": (uploaded_file.name, uploaded_file, uploaded_file.type)}
            response = requests.post("http://127.0.0.1:8000/upload_video/", files=files)
            if response.status_code != 200:
                st.error(f"Upload failed: {response.text}")
            else:
                file_name = response.json()["filename"]
                resp = requests.post("http://127.0.0.1:8000/process_video/", params={"file_name": file_name})
                if resp.status_code == 200:
                    st.success("✅ Video processed successfully!")

                    # List clips
                    clips = [f for f in os.listdir("tracking_video_clip") if f.endswith(".mp4")]
                    for clip in clips:
                        st.download_button(f"Download Clip: {clip}", f"http://127.0.0.1:8000/download_clip/{clip}")

                    # List zipped frames
                    zips = [f for f in os.listdir("tracking_video_clip") if f.endswith(".zip")]
                    for zipf in zips:
                        st.download_button(f"Download Frames: {zipf}", f"http://127.0.0.1:8000/download_frames/{zipf}")

                    # List JSONs
                    jsons = [f for f in os.listdir("tracking_json") if f.endswith(".json")]
                    for js in jsons:
                        st.download_button(f"Download JSON: {js}", f"http://127.0.0.1:8000/download_json/{js}")

                    # Dense proposals
                    st.download_button("Download dense_proposals.pkl",
                                        "http://127.0.0.1:8000/download_dense_proposals/")
                else:
                    st.error(f"Processing failed: {resp.text}")
