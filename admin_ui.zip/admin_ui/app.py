import os
import shutil
import zipfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from tools import clip_video, extract_frames, rename_resize, person_tracker, dense_proposals_train

UPLOAD_DIR = "uploads"
CLIP_DIR = "tracking_video_clip"
FRAME_DIR = "tracking_frames"
JSON_DIR = "tracking_json"
DENSE_DIR = "dense_proposals"

# Creating all necessary directories
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(CLIP_DIR, exist_ok=True)
os.makedirs(FRAME_DIR, exist_ok=True)
os.makedirs(JSON_DIR, exist_ok=True)
os.makedirs(DENSE_DIR, exist_ok=True)

app = FastAPI(title="Video Processing API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)
MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024 # 10 GB

# ---------------- Upload Video ----------------
@app.post("/upload_video/")
async def upload_video(file: UploadFile = File(...)):
    """Upload a video file to the server."""
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"filename": file.filename, "path": file_path}

# ---------------- Process Video ----------------
@app.post("/process_video/")
def process_video(file_name: str):
    """Process an uploaded video by clipping, extracting frames, and then tracking."""
    input_path = os.path.join(UPLOAD_DIR, file_name)
    if not os.path.exists(input_path):
        raise HTTPException(status_code=404, detail="Uploaded file not found.")

    print(f"Starting processing for file: {file_name}")

    # Clear previous clips to avoid processing old files
    shutil.rmtree(CLIP_DIR, ignore_errors=True)
    os.makedirs(CLIP_DIR, exist_ok=True)
    shutil.rmtree(FRAME_DIR, ignore_errors=True)
    os.makedirs(FRAME_DIR, exist_ok=True)

    # Step 1: Clip the specific uploaded video into 15-sec chunks
    print("Step 1: Clipping videos into 15-second chunks...")
    clip_video.clip_single_video(input_path, CLIP_DIR, clip_duration=15)
    
    # Step 2: Extract frames from the clipped videos
    print("Step 2: Extracting frames from clips...")
    extract_frames.extract_frames(CLIP_DIR, FRAME_DIR, fps=1)
    
    # Step 3: Run person tracking and generate a single JSON per clip
    print("Step 3: Running person tracking and generating JSON files...")
    for clip_file in os.listdir(CLIP_DIR):
        if clip_file.endswith(".mp4"):
            clip_path = os.path.join(CLIP_DIR, clip_file)
            video_id = Path(clip_file).stem
            # Initialize PersonTracker and process the video, saving JSON to JSON_DIR
            tracker = person_tracker.PersonTracker(video_id=video_id, conf=0.5)
            # This updated tracker function saves to the JSON directory
            tracker.process_video(clip_path, output_json_dir=JSON_DIR)
    
    # Step 4: Generate dense_proposals.pkl from the single JSON files
    print("Step 4: Generating dense_proposals.pkl...")
    dense_output = os.path.join(DENSE_DIR, "dense_proposals.pkl")
    dense_proposals_train.generate_dense_proposals(JSON_DIR, dense_output, img_width=1280, img_height=720, fps=15)

    print("Video processing complete! 🎉")
    return {
        "status": "success",
        "clips_dir": CLIP_DIR,
        "json_dir": JSON_DIR,
        "dense_proposals": dense_output
    }

# ---------------- Download Endpoints ----------------
@app.get("/download_clip/{clip_name}")
def download_clip(clip_name: str):
    """Download a processed video clip."""
    path = os.path.join(CLIP_DIR, clip_name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Clip not found.")
    return FileResponse(path, media_type="video/mp4", filename=clip_name)

@app.get("/download_json/{json_name}")
def download_json(json_name: str):
    """Download a single JSON file containing all detections for a clip."""
    path = os.path.join(JSON_DIR, json_name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="JSON not found.")
    return FileResponse(path, media_type="application/json", filename=json_name)

@app.get("/download_dense_proposals/")
def download_dense_proposals():
    """Download the final dense_proposals.pkl file."""
    path = os.path.join(DENSE_DIR, "dense_proposals.pkl")
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="dense_proposals.pkl not found.")
    return FileResponse(path, media_type="application/octet-stream", filename="dense_proposals.pkl")