# fastapi_cvat.py
import os
import pickle
import zipfile
import tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from proposals_to_cvat import process_clip  

app = FastAPI(title="CVAT Pre-Annotation Service")

# Reuse your attributes dictionary
attributes_dict = {
    '1': dict(aname='walking_behavior', type=2,
              options={'0': 'normal_walk', '1': 'fast_walk', '2': 'slow_walk', '3': 'standing_still',
                       '4': 'jogging', '5': 'window_shopping'}),
    '2': dict(aname='phone_usage', type=2,
              options={'0': 'no_phone', '1': 'talking_phone', '2': 'texting', '3': 'taking_photo',
                       '4': 'listening_music'}),
    '3': dict(aname='social_interaction', type=2,
              options={'0': 'alone', '1': 'talking_companion', '2': 'group_walking', '3': 'greeting_someone',
                       '4': 'asking_directions', '5': 'avoiding_crowd'}),
    '4': dict(aname='carrying_items', type=2,
              options={'0': 'empty_hands', '1': 'shopping_bags', '2': 'backpack', '3': 'briefcase_bag',
                       '4': 'umbrella', '5': 'food_drink', '6': 'multiple_items'}),
    '5': dict(aname='street_behavior', type=2,
              options={'0': 'sidewalk_walking', '1': 'crossing_street', '2': 'waiting_signal',
                       '3': 'looking_around', '4': 'checking_map', '5': 'entering_building',
                       '6': 'exiting_building'}),
    '6': dict(aname='posture_gesture', type=2,
              options={'0': 'upright_normal', '1': 'looking_down', '2': 'looking_up', '3': 'hands_in_pockets',
                       '4': 'arms_crossed', '5': 'pointing_gesture', '6': 'bowing_gesture'}),
    '7': dict(aname='clothing_style', type=2,
              options={'0': 'business_attire', '1': 'casual_wear', '2': 'tourist_style', '3': 'school_uniform',
                       '4': 'sports_wear', '5': 'traditional_wear'}),
    '8': dict(aname='time_context', type=2,
              options={'0': 'rush_hour', '1': 'leisure_time', '2': 'shopping_time', '3': 'tourist_hours',
                       '4': 'lunch_break', '5': 'evening_stroll'})
}

@app.post("/process_clips/")
async def process_clips(pickle_file: UploadFile = File(...), frames_zip: UploadFile = File(...)):
    """
    Upload a dense_proposals.pkl and frames.zip folder to generate CVAT-ready ZIP packages.
    """
    # Create a temporary working directory
    work_dir = tempfile.mkdtemp()
    pickle_path = os.path.join(work_dir, "dense_proposals.pkl")
    frame_dir = os.path.join(work_dir, "frames")
    output_dir = os.path.join(work_dir, "output")
    os.makedirs(frame_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    # Save uploaded pickle file
    with open(pickle_path, "wb") as f:
        f.write(await pickle_file.read())

    # Save and extract frames ZIP
    frames_zip_path = os.path.join(work_dir, "frames.zip")
    with open(frames_zip_path, "wb") as f:
        f.write(await frames_zip.read())
    with zipfile.ZipFile(frames_zip_path, "r") as zip_ref:
        zip_ref.extractall(frame_dir)

    # Load pickle
    try:
        with open(pickle_path, 'rb') as f:
            proposals_data = pickle.load(f)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read pickle file: {e}")

    # Process each clip
    for video_id, frames_data in proposals_data.items():
        process_clip(video_id, frames_data, frame_dir, output_dir, attributes_dict)

    # Package all output ZIPs into a single ZIP
    final_zip_path = os.path.join(work_dir, "cvat_packages.zip")
    with zipfile.ZipFile(final_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in Path(output_dir).rglob("*.zip"):
            zf.write(file, arcname=file.name)

    return FileResponse(
        final_zip_path,
        media_type="application/zip",
        filename="cvat_packages.zip"
    )
